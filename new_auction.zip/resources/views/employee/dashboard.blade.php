@extends('employee.app')
{{-- @section('title') {{ $pageTitle }} @endsection --}}
@section('content')
    <div class="inner-content">
        <div class="status-panel">
            <div class="container-fluid">
                <hi>Employee Dashboard</hi>
            </div>
        </div>
    </div>
@endsection
@push('scripts')
@endpush