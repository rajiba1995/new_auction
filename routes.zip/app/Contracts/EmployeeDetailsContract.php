<?php

namespace App\Contracts;
use Illuminate\Http\Request;

interface EmployeeDetailsContract{
    // public function getAllUsers();
    // // public function getSearchUser(Request $request);
    // public function getUserAllDocumentsById(int $id);

}