<?php

namespace App\Contracts;

interface BuyerDashboardContract{
} 
?>